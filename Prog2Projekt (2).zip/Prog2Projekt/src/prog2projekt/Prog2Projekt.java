package prog2projekt;

public class Prog2Projekt {
    
    public static void main(String[] args) {
        Table tb = new Table();
        tb.setVisible(true);
    }
    
}
